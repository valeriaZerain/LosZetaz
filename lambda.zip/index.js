const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async () => {
  try {
    const clubs = [
        {
            id: 0,
            logo: "logo_vanity",
            ownerEmail: "vanity@vanity.com",
            name: "Vanity",
            license: "90800124A-B24235510",
            latitude: -16.5329912,
            longitude: -68.0869359,
            cover: 35,
            schedule: "Viernes y Sabados: 5:00 PM - 2:00 AM",
            recommendations: "Llevate dinero para el taxi",
            contactNumber: 12345678,
            tags: "[false, true, true, false, false]",
            likes: 10,
            zone: "Irpavi",
            logoString: null
        },
        {
            id: 1,
            logo: "logo_garden",
            ownerEmail: "garden@garden.com",
            name: "Garden",
            license: "90800124A-B24235510",
            latitude: -16.5386299,
            longitude: -68.0855887,
            cover: 45,
            schedule: "Viernes y Sabados: 5:30 PM - 2:00 AM",
            recommendations: "Vente preparada que el ambiente está más caliente que una llajua con aji",
            contactNumber: 12345678,
            tags: "[false, false, true, false, false]",
            likes: 20,
            zone: "Calacoto",
            logoString: null
        },
        {
            id: 2,
            logo: "logo_gold",
            ownerEmail: "gold@gold.com",
            name: "Gold",
            license: "90800124A-B24235510",
            latitude: -16.5034961,
            longitude: -68.1407517,
            cover: 20,
            schedule: "Viernes y Sabados: 9:00 PM - 2:00 AM",
            recommendations: "",
            contactNumber: 12345678,
            tags: "[false, true, false, false, true]",
            likes: 15,
            zone: "San Pedro",
            logoString: null
        },
        {
            id: 3,
            logo: "logo_malegria",
            ownerEmail: "malegria@malegria.com",
            name: "Malegria",
            license: "90800124A-B24235510",
            latitude: -16.5091348,
            longitude: -68.1307563,
            cover: 30,
            schedule: "Viernes y Sabados: 5:00 PM - 2:00 AM",
            recommendations: "Ven temprano que se llena rapido",
            contactNumber: 12345678,
            tags: "[false, true, true, false, false]",
            likes: 30,
            zone: "Sopocachi",
            logoString: null
        },
        {
            id: 4,
            logo: "logo_pacha",
            ownerEmail: "pacha@pacha.com",
            name: "Pacha",
            license: "90800124A-B24235510",
            latitude: -16.5423575,
            longitude: -68.0682857,
            cover: 50,
            schedule: "Viernes y Sabados: 5:00 PM - 2:00 AM",
            recommendations: "Reserva tu mesa",
            contactNumber: 12345678,
            tags: "[true, false, true, false, false]",
            likes: 50,
            zone: "Cota Cota",
            logoString: null
        },
        {
            id: 5,
            logo: "logo_taboo",
            ownerEmail: "taboo@taboo.com",
            name: "Taboo",
            license: "90800124A-B24235510",
            latitude: -16.540276,
            longitude: -68.070082,
            cover: 30,
            schedule: "Viernes y Sabados: 5:00 PM - 2:00 AM",
            recommendations: "Deja tu corazon en tu casa y ven a divertirte",
            contactNumber: 12345678,
            tags: "[true, false, true, false, false]",
            likes: 35,
            zone: "Cota Cota",
            logoString: null
        },
        {
            id: 6,
            logo: "logo_fabula",
            ownerEmail: "fabula@fabula.com",
            name: "Fabula",
            license: "90800124A-B24235510",
            latitude: -16.5453672,
            longitude: -68.0615611,
            cover: 30,
            schedule: "Viernes y Sabados: 7:00 PM - 2:00 AM",
            recommendations: "Llevate abrigo",
            contactNumber: 12345678,
            tags: "[true, true, true, false, false]",
            likes: 25,
            zone: "Cota Cota",
            logoString: null
        },
        {
            id: 7,
            logo: "logo_black_monkey",
            ownerEmail: "black@black.com",
            name: "Black Monkey Bar",
            license: "90800124A-B24235510",
            latitude: -16.5384633,
            longitude: -68.0856271,
            cover: 30,
            schedule: "Viernes y Sabados: 7:00 PM - 2:00 AM",
            recommendations: "",
            contactNumber: 12345678,
            tags: "[false, true, true, false, true]",
            likes: 15,
            zone: "Calacoto",
            logoString: null
        },
        {
            id: 8,
            logo: "logo_forum",
            ownerEmail: "forum@forum.com",
            name: "Forum",
            license: "90800124A-B24235510",
            latitude: -16.5161706,
            longitude: -68.1313766,
            cover: 25,
            schedule: "Viernes y Sabados: 9:00 PM - 2:00 AM",
            recommendations: "Mientras mas tarde mejor",
            contactNumber: 12345678,
            tags: "[false, false, false, false, true]",
            likes: 10,
            zone: "Sopocachi",
            logoString: null
        },
        {
            id: 9,
            logo: "logo_zouk",
            ownerEmail: "zoruk@zoruk.com",
            name: "Zoruk Boulevard",
            license: "90800124A-B24235510",
            latitude: -16.5426472,
            longitude: -68.0797515,
            cover: 40,
            schedule: "Sabados: 9:00 PM - 2:00 AM",
            recommendations: "",
            contactNumber: 12345678,
            tags: "[false, true, false, false, false]",
            likes: 26,
            zone: "Calacoto",
            logoString: null
        },
        {
            id: 10,
            logo: "logo_wave",
            ownerEmail: "wave@wave.com",
            name: "Wave Club",
            license: "90800124A-B24235510",
            latitude: -16.5438751,
            longitude: -68.08003,
            cover: 0,
            schedule: "Viernes y Sabados: 6:00 PM - 23:59 PM",
            recommendations: "Hipoteca la casa",
            contactNumber: 12345678,
            tags: "[false, false, true, false, false]",
            likes: 26,
            zone: "Calacoto",
            logoString: null
        }
    ];


    const posts = [
          {
            const posts = [
              {
                id: 0,
                title: "🎃 PACHAWEEN🎃",
                date: "2023-10-25",
                description: "¡Este sábado tenemos un line up imperdible! Prepara tu mejor disfraz para bailar por horas.",
                image: "post_pacha_pachaween",
                clubId: 4,
                imageString: ""
              },
              {
                id: 1,
                title: "Calle de las brujas",
                date: "2023-10-17",
                description: "¡La previa a Halloween 🎃 👻 es en Pachita! La Calle de brujas!!",
                image: "post_pacha_calle_brujas",
                clubId: 4,
                imageString: ""
              },
              {
                id: 2,
                title: "Dia de los muertos",
                date: "2023-10-25",
                description: "Day of the Dead, Awaken the Fiesta💀",
                image: "post_taboo_dia_muertos",
                clubId: 5,
                imageString: ""
              },
              {
                id: 3,
                title: "Rompe con la rutina",
                date: "2023-10-24",
                description: "🔥 Este Miércoles en Malegria, la fiesta número uno en Sopocachi, La Paz, Bolivia, te espera con una irresistible oferta. Reúnete con tus amigos y prepárate para vivir una noche inolvidable con nuestras promociones especiales: 🍹 2x1 en todos nuestros cócteles. 🍹 ¡No te pierdas la oportunidad de degustar nuestras exquisitas creaciones! 🎧 ¡Tú eres el DJ! 🎧 Ponemos el control de la música en tus manos para que disfrutes de tus canciones favoritas toda la noche",
                image: "post_malegria_2x1",
                clubId: 3,
                imageString: ""

          }
        ];

    const users = [
      {
        id: 1,
        username: "Valeria",
        email: "valeria.zerain@gmail.com",
        cellphone: 60627590,
        birthday: "17-06-2003",
        ci:8428124,
        likedIdClubs: 1,
        profilePictureString:""
      }
    ];

    // Insertar datos en DynamoDB
    for (const club of clubs) {
      await dynamodb
        .put({
          TableName: process.env.DYNAMODB_TABLE_CLUBS,
          Item: club
        })
        .promise();
    }

    for (const user of users) {
      await dynamodb
        .put({
          TableName: process.env.DYNAMODB_TABLE_USERS,
          Item: user
        })
        .promise();
    }

    return {
      statusCode: 200,
      body: JSON.stringify("Datos inicializados correctamente")
    };
  } catch (error) {
    console.error("Error al inicializar datos:", error);
    return {
      statusCode: 500,
      body: JSON.stringify("Error al inicializar datos")
    };
  }
};